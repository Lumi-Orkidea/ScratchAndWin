﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class randomSprite : MonoBehaviour
{
    public SpriteRenderer spriteRenderer;
    public Sprite[] spriteArray; // array of all the symbol sprites
    
    /*
     * Randomizes one of the sprites to be used.
     */
    void Start()
    {
        spriteRenderer = gameObject.GetComponent<SpriteRenderer>();
        spriteRenderer.sprite = spriteArray[Random.Range(0,spriteArray.Length)];
    }
}
